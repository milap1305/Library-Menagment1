
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

def _base_receipt(file_path, title, rows):
    c = canvas.Canvas(file_path, pagesize=A4)
    width, height = A4
    y = height - 80

    c.setFont("Helvetica-Bold", 16)
    c.drawCentredString(width / 2, y, title)
    y -= 30
    c.line(60, y, width - 60, y)
    y -= 30

    c.setFont("Helvetica", 11)
    for label, value in rows:
        c.drawString(80, y, f"{label}: {value}")
        y -= 18

    y -= 20
    c.drawString(80, y, "Thank you for using the library.")
    c.showPage()
    c.save()

def create_issue_receipt(issue, file_path):
    rows = [
        ("Issue ID", issue["id"]),
        ("Member", issue["member_name"]),
        ("Book", issue["book_title"]),
        ("Serial No", issue["serial_no"]),
        ("Issue Date", issue["issue_date"]),
        ("Due Date", issue["due_date"]),
    ]
    _base_receipt(file_path, "ISSUE RECEIPT", rows)

def create_return_receipt(issue, file_path):
    rows = [
        ("Issue ID", issue["id"]),
        ("Member", issue["member_name"]),
        ("Book", issue["book_title"]),
        ("Serial No", issue["serial_no"]),
        ("Issue Date", issue["issue_date"]),
        ("Due Date", issue["due_date"]),
        ("Return Date", issue["return_date"]),
        ("Penalty", issue["penalty"]),
    ]
    _base_receipt(file_path, "RETURN RECEIPT", rows)
