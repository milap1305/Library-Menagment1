
from datetime import datetime

PENALTY_PER_DAY = 5  # simple rule: 5 units per late day

def calculate_penalty(due_date_str, return_date_str):
    try:
        due = datetime.strptime(due_date_str, "%Y-%m-%d").date()
        ret = datetime.strptime(return_date_str, "%Y-%m-%d").date()
    except Exception:
        return 0
    if ret <= due:
        return 0
    days_late = (ret - due).days
    return days_late * PENALTY_PER_DAY
