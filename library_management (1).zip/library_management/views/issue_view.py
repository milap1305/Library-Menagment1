
from tkinter import *
from tkinter import ttk, messagebox, filedialog
from datetime import date
from utils.receipt_pdf import create_issue_receipt

class IssueView(Frame):
    def __init__(self, parent, issue_controller, stock_controller, member_controller):
        super().__init__(parent, bg="#f0fff0")
        self.issue_controller = issue_controller
        self.stock_controller = stock_controller
        self.member_controller = member_controller
        self.build_ui()

    def build_ui(self):
        Label(self, text="Book Issue", font=("Arial", 16, "bold"), bg="#f0fff0").pack(pady=10)
        container = Frame(self, bg="#f0fff0")
        container.pack(fill=BOTH, expand=True)

        # Left: issue form
        form = LabelFrame(container, text="Issue Form", bg="#f0fff0")
        form.pack(side=LEFT, fill=Y, padx=10, pady=10)

        Label(form, text="Member:", bg="#f0fff0").grid(row=0, column=0, sticky=W, pady=3)
        self.member_var = StringVar()
        self.member_combo = ttk.Combobox(form, textvariable=self.member_var, state="readonly", width=30)
        self.member_combo.grid(row=0, column=1, pady=3)

        Label(form, text="Copy (Serial):", bg="#f0fff0").grid(row=1, column=0, sticky=W, pady=3)
        self.copy_var = StringVar()
        self.copy_combo = ttk.Combobox(form, textvariable=self.copy_var, state="readonly", width=30)
        self.copy_combo.grid(row=1, column=1, pady=3)

        Label(form, text="Issue Date:", bg="#f0fff0").grid(row=2, column=0, sticky=W, pady=3)
        self.issue_date_var = StringVar(value=date.today().isoformat())
        Entry(form, textvariable=self.issue_date_var).grid(row=2, column=1, pady=3)

        Label(form, text="Due Date:", bg="#f0fff0").grid(row=3, column=0, sticky=W, pady=3)
        self.due_date_var = StringVar()
        Entry(form, textvariable=self.due_date_var).grid(row=3, column=1, pady=3)

        Button(form, text="Load Members / Copies", command=self.load_members_copies).grid(row=4, column=0, columnspan=2, pady=5, sticky="ew")
        Button(form, text="Issue Book", command=self.issue_book).grid(row=5, column=0, columnspan=2, pady=5, sticky="ew")

        # Right: list of current issues
        list_frame = LabelFrame(container, text="Current Issues", bg="#f0fff0")
        list_frame.pack(side=RIGHT, fill=BOTH, expand=True, padx=10, pady=10)

        cols = ("id","member","book","serial_no","issue_date","due_date")
        self.tree = ttk.Treeview(list_frame, columns=cols, show="headings", height=15)
        for col, text in zip(cols, ["Issue ID","Member","Book","Serial No","Issue Date","Due Date"]):
            self.tree.heading(col, text=text)
            self.tree.column(col, width=120, anchor=W)
        self.tree.pack(fill=BOTH, expand=True, pady=(0,5))

        btn_frame = Frame(list_frame, bg="#f0fff0")
        btn_frame.pack(fill=X)
        Button(btn_frame, text="Refresh", command=self.refresh_issues).pack(side=LEFT, padx=5, pady=5)
        Button(btn_frame, text="Download Receipt", command=self.download_receipt).pack(side=LEFT, padx=5, pady=5)

        self.refresh_issues()
        self.load_members_copies()

    def load_members_copies(self):
        # members
        mrows = self.member_controller.list_members()
        member_items = [f"{r['id']} - {r['name']}" for r in mrows]
        self.member_combo["values"] = member_items
        # available copies
        crows = self.stock_controller.list_available_copies()
        copy_items = [f"{r['id']} - {r['serial_no']} ({r['book_title']})" for r in crows]
        self.copy_combo["values"] = copy_items

    def issue_book(self):
        if not self.member_var.get() or not self.copy_var.get():
            messagebox.showerror("Error", "Select member and copy")
            return
        member_id = int(self.member_var.get().split(" - ")[0])
        copy_id = int(self.copy_var.get().split(" - ")[0])
        issue_date = self.issue_date_var.get().strip()
        due_date = self.due_date_var.get().strip()
        if not due_date:
            messagebox.showerror("Error", "Due date is required")
            return
        ok, res = self.issue_controller.issue_book(copy_id, member_id, issue_date, due_date)
        if ok:
            messagebox.showinfo("Success", f"Issued. Issue ID: {res}")
            self.refresh_issues()
            self.load_members_copies()
        else:
            messagebox.showerror("Error", res)

    def refresh_issues(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        rows = self.issue_controller.list_current_issues()
        for r in rows:
            self.tree.insert("", END, values=(r["id"], r["member_name"], r["book_title"], r["serial_no"], r["issue_date"], r["due_date"]))

    def download_receipt(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select an issue from the list")
            return
        item = self.tree.item(selected[0])
        issue_id = item["values"][0]
        ok, row = self.issue_controller.get_issue_details(issue_id)
        if not ok:
            messagebox.showerror("Error", row)
            return
        from tkinter import filedialog
        file_path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            initialfile=f"issue_receipt_{issue_id}.pdf",
            filetypes=[("PDF files","*.pdf")]
        )
        if not file_path:
            return
        create_issue_receipt(row, file_path)
        messagebox.showinfo("Saved", f"Receipt saved to:\n{file_path}")
