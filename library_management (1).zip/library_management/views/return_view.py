
from tkinter import *
from tkinter import ttk, messagebox, filedialog
from datetime import date
from utils.receipt_pdf import create_return_receipt
from utils.penalty import calculate_penalty

class ReturnView(Frame):
    def __init__(self, parent, issue_controller):
        super().__init__(parent, bg="#f0fff0")
        self.issue_controller = issue_controller
        self.build_ui()

    def build_ui(self):
        Label(self, text="Book Return", font=("Arial", 16, "bold"), bg="#f0fff0").pack(pady=10)
        container = Frame(self, bg="#f0fff0")
        container.pack(fill=BOTH, expand=True)

        form = LabelFrame(container, text="Return Form", bg="#f0fff0")
        form.pack(side=LEFT, fill=Y, padx=10, pady=10)

        Label(form, text="Issue ID:", bg="#f0fff0").grid(row=0, column=0, sticky=W, pady=3)
        self.issue_id_var = StringVar()
        Entry(form, textvariable=self.issue_id_var).grid(row=0, column=1, pady=3)

        Label(form, text="Return Date:", bg="#f0fff0").grid(row=1, column=0, sticky=W, pady=3)
        self.return_date_var = StringVar(value=date.today().isoformat())
        Entry(form, textvariable=self.return_date_var).grid(row=1, column=1, pady=3)

        Button(form, text="Return Book", command=self.return_book).grid(row=2, column=0, columnspan=2, pady=8, sticky="ew")

        # List of returned
        list_frame = LabelFrame(container, text="Returned History", bg="#f0fff0")
        list_frame.pack(side=RIGHT, fill=BOTH, expand=True, padx=10, pady=10)

        cols = ("id","member","book","serial_no","issue_date","due_date","return_date","penalty")
        self.tree = ttk.Treeview(list_frame, columns=cols, show="headings", height=15)
        for col, text in zip(cols, ["Issue ID","Member","Book","Serial","Issue Date","Due Date","Return Date","Penalty"]):
            self.tree.heading(col, text=text)
            self.tree.column(col, width=100, anchor=W)
        self.tree.pack(fill=BOTH, expand=True, pady=(0,5))

        btn_frame = Frame(list_frame, bg="#f0fff0")
        btn_frame.pack(fill=X)
        Button(btn_frame, text="Refresh", command=self.refresh_returns).pack(side=LEFT, padx=5, pady=5)
        Button(btn_frame, text="Download Receipt", command=self.download_receipt).pack(side=LEFT, padx=5, pady=5)

        self.refresh_returns()

    def return_book(self):
        try:
            issue_id = int(self.issue_id_var.get())
        except ValueError:
            messagebox.showerror("Error", "Enter valid Issue ID")
            return
        ok, row = self.issue_controller.get_issue_details(issue_id)
        if not ok:
            messagebox.showerror("Error", row)
            return
        ret_date = self.return_date_var.get().strip()
        penalty = calculate_penalty(row["due_date"], ret_date)
        ok2, msg2 = self.issue_controller.return_book(issue_id, ret_date, penalty)
        if ok2:
            messagebox.showinfo("Returned", f"Book returned. Penalty: {penalty}")
            self.refresh_returns()
        else:
            messagebox.showerror("Error", msg2)

    def refresh_returns(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        rows = self.issue_controller.list_returned()
        for r in rows:
            self.tree.insert("", END, values=(
                r["id"], r["member_name"], r["book_title"], r["serial_no"],
                r["issue_date"], r["due_date"], r["return_date"], r["penalty"]
            ))

    def download_receipt(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select a return from the list")
            return
        item = self.tree.item(selected[0])
        issue_id = item["values"][0]
        ok, row = self.issue_controller.get_issue_details(issue_id)
        if not ok:
            messagebox.showerror("Error", row)
            return
        file_path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            initialfile=f"return_receipt_{issue_id}.pdf",
            filetypes=[("PDF files","*.pdf")]
        )
        if not file_path:
            return
        create_return_receipt(row, file_path)
        messagebox.showinfo("Saved", f"Receipt saved to:\n{file_path}")
