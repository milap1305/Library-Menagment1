
from tkinter import *
from tkinter import ttk, messagebox

class BooksView(Frame):
    def __init__(self, parent, book_controller, stock_controller):
        super().__init__(parent, bg="#f0fff0")
        self.book_controller = book_controller
        self.stock_controller = stock_controller
        self.build_ui()

    def build_ui(self):
        Label(self, text="Books Master & Stock", font=("Arial", 16, "bold"), bg="#f0fff0").pack(pady=10)

        container = Frame(self, bg="#f0fff0")
        container.pack(fill=BOTH, expand=True)

        # Left - Book master
        book_frame = LabelFrame(container, text="Book Master", bg="#f0fff0")
        book_frame.pack(side=LEFT, fill=Y, padx=10, pady=10)

        Label(book_frame, text="Title:", bg="#f0fff0").grid(row=0, column=0, sticky=W, pady=3)
        self.title_var = StringVar()
        Entry(book_frame, textvariable=self.title_var, width=30).grid(row=0, column=1, pady=3)

        Label(book_frame, text="Author:", bg="#f0fff0").grid(row=1, column=0, sticky=W, pady=3)
        self.author_var = StringVar()
        Entry(book_frame, textvariable=self.author_var, width=30).grid(row=1, column=1, pady=3)

        Label(book_frame, text="Category:", bg="#f0fff0").grid(row=2, column=0, sticky=W, pady=3)
        self.category_var = StringVar()
        Entry(book_frame, textvariable=self.category_var, width=30).grid(row=2, column=1, pady=3)

        Label(book_frame, text="ISBN:", bg="#f0fff0").grid(row=3, column=0, sticky=W, pady=3)
        self.isbn_var = StringVar()
        Entry(book_frame, textvariable=self.isbn_var, width=30).grid(row=3, column=1, pady=3)

        Button(book_frame, text="Add Book", command=self.add_book).grid(row=4, column=0, columnspan=2, pady=10, sticky="ew")

        # Right - stock (copies)
        stock_frame = LabelFrame(container, text="Book Copies / Stock", bg="#f0fff0")
        stock_frame.pack(side=RIGHT, fill=BOTH, expand=True, padx=10, pady=10)

        top = Frame(stock_frame, bg="#f0fff0")
        top.pack(fill=X)

        Label(top, text="Book ID:", bg="#f0fff0").grid(row=0, column=0, sticky=W, pady=3)
        self.stock_book_id_var = StringVar()
        Entry(top, textvariable=self.stock_book_id_var, width=10).grid(row=0, column=1, pady=3)

        Label(top, text="Serial No:", bg="#f0fff0").grid(row=0, column=2, sticky=W, pady=3, padx=(10,0))
        self.serial_var = StringVar()
        Entry(top, textvariable=self.serial_var, width=15).grid(row=0, column=3, pady=3)

        Button(top, text="Add Copy", command=self.add_copy).grid(row=0, column=4, padx=10, pady=3)

        # Manual status update
        Label(top, text="Copy ID:", bg="#f0fff0").grid(row=1, column=0, sticky=W, pady=3)
        self.copy_id_update_var = StringVar()
        Entry(top, textvariable=self.copy_id_update_var, width=10).grid(row=1, column=1, pady=3)

        Label(top, text="Status:", bg="#f0fff0").grid(row=1, column=2, sticky=W, pady=3)
        self.status_var = StringVar()
        self.status_combo = ttk.Combobox(top, textvariable=self.status_var, values=["available","issued","reserved"], width=12, state="readonly")
        self.status_combo.grid(row=1, column=3, pady=3)
        self.status_combo.current(0)

        Button(top, text="Update Status", command=self.update_status).grid(row=1, column=4, padx=10, pady=3)

        # Stock list
        columns = ("id","book_id","book_title","serial_no","status")
        self.tree = ttk.Treeview(stock_frame, columns=columns, show="headings", height=15)
        for col, text in zip(columns, ["Copy ID","Book ID","Book Title","Serial No","Status"]):
            self.tree.heading(col, text=text)
            self.tree.column(col, width=100, anchor=W)
        self.tree.pack(fill=BOTH, expand=True, pady=(5,0))

        Button(stock_frame, text="Refresh", command=self.refresh_stock).pack(pady=5)

        self.refresh_stock()

    def add_book(self):
        ok, msg = self.book_controller.add_book(
            self.title_var.get().strip(),
            self.author_var.get().strip(),
            self.category_var.get().strip(),
            self.isbn_var.get().strip(),
        )
        if ok:
            messagebox.showinfo("Success", msg)
            self.title_var.set("")
            self.author_var.set("")
            self.category_var.set("")
            self.isbn_var.set("")
        else:
            messagebox.showerror("Error", msg)

    def add_copy(self):
        try:
            book_id = int(self.stock_book_id_var.get())
        except ValueError:
            messagebox.showerror("Error", "Enter valid Book ID")
            return
        ok, msg = self.stock_controller.add_copy(book_id, self.serial_var.get().strip())
        if ok:
            messagebox.showinfo("Success", msg)
            self.serial_var.set("")
            self.refresh_stock()
        else:
            messagebox.showerror("Error", msg)

    def update_status(self):
        try:
            copy_id = int(self.copy_id_update_var.get())
        except ValueError:
            messagebox.showerror("Error", "Enter valid Copy ID")
            return
        status = self.status_var.get()
        ok, msg = self.stock_controller.update_status(copy_id, status)
        if ok:
            messagebox.showinfo("Success", msg)
            self.refresh_stock()
        else:
            messagebox.showerror("Error", msg)

    def refresh_stock(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        rows = self.stock_controller.list_copies()
        for r in rows:
            self.tree.insert("", END, values=(r["id"], r["book_id"], r["book_title"], r["serial_no"], r["status"]))
