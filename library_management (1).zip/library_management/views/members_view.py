
from tkinter import *
from tkinter import ttk, messagebox

class MembersView(Frame):
    def __init__(self, parent, member_controller):
        super().__init__(parent, bg="#f0fff0")
        self.member_controller = member_controller
        self.build_ui()

    def build_ui(self):
        Label(self, text="Member Master", font=("Arial", 16, "bold"), bg="#f0fff0").pack(pady=10)

        form = Frame(self, bg="#f0fff0")
        form.pack(fill=X, padx=10, pady=5)

        Label(form, text="Name:", bg="#f0fff0").grid(row=0, column=0, sticky=W, pady=3)
        self.name_var = StringVar()
        Entry(form, textvariable=self.name_var, width=30).grid(row=0, column=1, pady=3)

        Label(form, text="Email:", bg="#f0fff0").grid(row=1, column=0, sticky=W, pady=3)
        self.email_var = StringVar()
        Entry(form, textvariable=self.email_var, width=30).grid(row=1, column=1, pady=3)

        Label(form, text="Phone:", bg="#f0fff0").grid(row=2, column=0, sticky=W, pady=3)
        self.phone_var = StringVar()
        Entry(form, textvariable=self.phone_var, width=30).grid(row=2, column=1, pady=3)

        Button(form, text="Add Member", command=self.add_member).grid(row=3, column=0, columnspan=2, pady=10, sticky="ew")

        columns = ("id","name","email","phone","join_date")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=15)
        for col, text in zip(columns, ["ID","Name","Email","Phone","Join Date"]):
            self.tree.heading(col, text=text)
            self.tree.column(col, width=120, anchor=W)
        self.tree.pack(fill=BOTH, expand=True, padx=10, pady=(5,10))

        Button(self, text="Refresh", command=self.refresh_members).pack(pady=(0,10))

        self.refresh_members()

    def add_member(self):
        ok, msg = self.member_controller.add_member(
            self.name_var.get().strip(),
            self.email_var.get().strip(),
            self.phone_var.get().strip(),
        )
        if ok:
            messagebox.showinfo("Success", msg)
            self.name_var.set("")
            self.email_var.set("")
            self.phone_var.set("")
            self.refresh_members()
        else:
            messagebox.showerror("Error", msg)

    def refresh_members(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        rows = self.member_controller.list_members()
        for r in rows:
            self.tree.insert("", END, values=(r["id"], r["name"], r["email"], r["phone"], r["join_date"]))
