
from tkinter import *
from tkinter import ttk, messagebox
from datetime import date

class ReservationView(Frame):
    def __init__(self, parent, reservation_controller, stock_controller, member_controller):
        super().__init__(parent, bg="#f0fff0")
        self.reservation_controller = reservation_controller
        self.stock_controller = stock_controller
        self.member_controller = member_controller
        self.build_ui()

    def build_ui(self):
        Label(self, text="Advance Reservation", font=("Arial", 16, "bold"), bg="#f0fff0").pack(pady=10)
        container = Frame(self, bg="#f0fff0")
        container.pack(fill=BOTH, expand=True)

        form = LabelFrame(container, text="Reserve Book", bg="#f0fff0")
        form.pack(side=LEFT, fill=Y, padx=10, pady=10)

        Label(form, text="Member:", bg="#f0fff0").grid(row=0, column=0, sticky=W, pady=3)
        self.member_var = StringVar()
        self.member_combo = ttk.Combobox(form, textvariable=self.member_var, state="readonly", width=30)
        self.member_combo.grid(row=0, column=1, pady=3)

        Label(form, text="Copy (Serial):", bg="#f0fff0").grid(row=1, column=0, sticky=W, pady=3)
        self.copy_var = StringVar()
        self.copy_combo = ttk.Combobox(form, textvariable=self.copy_var, state="readonly", width=30)
        self.copy_combo.grid(row=1, column=1, pady=3)

        Button(form, text="Load Members / Copies", command=self.load_members_copies).grid(row=2, column=0, columnspan=2, pady=5, sticky="ew")
        Button(form, text="Reserve", command=self.reserve_copy).grid(row=3, column=0, columnspan=2, pady=5, sticky="ew")

        list_frame = LabelFrame(container, text="Reservations", bg="#f0fff0")
        list_frame.pack(side=RIGHT, fill=BOTH, expand=True, padx=10, pady=10)

        cols = ("id","member","book","serial_no","reserve_date","status")
        self.tree = ttk.Treeview(list_frame, columns=cols, show="headings", height=15)
        for col, text in zip(cols, ["ID","Member","Book","Serial","Reserve Date","Status"]):
            self.tree.heading(col, text=text)
            self.tree.column(col, width=110, anchor=W)
        self.tree.pack(fill=BOTH, expand=True, pady=(0,5))

        btn_frame = Frame(list_frame, bg="#f0fff0")
        btn_frame.pack(fill=X)
        Button(btn_frame, text="Refresh", command=self.refresh_reservations).pack(side=LEFT, padx=5, pady=5)
        Button(btn_frame, text="Cancel Reservation", command=self.cancel_reservation).pack(side=LEFT, padx=5, pady=5)

        self.refresh_reservations()
        self.load_members_copies()

    def load_members_copies(self):
        mrows = self.member_controller.list_members()
        self.member_combo["values"] = [f"{r['id']} - {r['name']}" for r in mrows]
        crows = self.stock_controller.list_available_copies()
        self.copy_combo["values"] = [f"{r['id']} - {r['serial_no']} ({r['book_title']})" for r in crows]

    def reserve_copy(self):
        if not self.member_var.get() or not self.copy_var.get():
            messagebox.showerror("Error", "Select member and copy")
            return
        member_id = int(self.member_var.get().split(" - ")[0])
        copy_id = int(self.copy_var.get().split(" - ")[0])
        ok, msg = self.reservation_controller.reserve_copy(copy_id, member_id)
        if ok:
            messagebox.showinfo("Success", msg)
            self.refresh_reservations()
            self.load_members_copies()
        else:
            messagebox.showerror("Error", msg)

    def refresh_reservations(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        rows = self.reservation_controller.list_reservations()
        for r in rows:
            self.tree.insert("", END, values=(
                r["id"], r["member_name"], r["book_title"], r["serial_no"], r["reserve_date"], r["status"]
            ))

    def cancel_reservation(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Select a reservation from the list")
            return
        item = self.tree.item(selected[0])
        res_id = item["values"][0]
        ok, msg = self.reservation_controller.cancel_reservation(res_id)
        if ok:
            messagebox.showinfo("Cancelled", msg)
            self.refresh_reservations()
        else:
            messagebox.showerror("Error", msg)
