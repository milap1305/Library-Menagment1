
from datetime import date
from db import get_connection

class ReservationModel:
    def reserve_copy(self, copy_id, member_id):
        if not copy_id or not member_id:
            return False, "Copy and member are required"
        conn = get_connection()
        cur = conn.cursor()

        cur.execute("SELECT status FROM book_copies WHERE id=?", (copy_id,))
        row = cur.fetchone()
        if not row:
            conn.close()
            return False, "Copy not found"
        if row["status"] != "available":
            conn.close()
            return False, f"Copy is not available ({row['status']})"

        cur.execute(
            "INSERT INTO reservations (copy_id, member_id, reserve_date, status) "
            "VALUES (?, ?, ?, 'reserved')",
            (copy_id, member_id, date.today().isoformat()),
        )
        # mark copy as reserved
        cur.execute("UPDATE book_copies SET status='reserved' WHERE id=?", (copy_id,))

        conn.commit()
        conn.close()
        return True, "Reserved"

    def cancel_reservation(self, res_id):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM reservations WHERE id=?", (res_id,))
        r = cur.fetchone()
        if not r:
            conn.close()
            return False, "Reservation not found"
        if r["status"] != "reserved":
            conn.close()
            return False, "Reservation already cancelled/processed"
        cur.execute("UPDATE reservations SET status='cancelled' WHERE id=?", (res_id,))
        # free copy
        cur.execute("UPDATE book_copies SET status='available' WHERE id=?", (r["copy_id"],))
        conn.commit()
        conn.close()
        return True, "Cancelled"

    def list_reservations(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT r.id, m.name AS member_name, b.title AS book_title, "
            "c.serial_no, r.reserve_date, r.status "
            "FROM reservations r "
            "JOIN members m ON r.member_id=m.id "
            "JOIN book_copies c ON r.copy_id=c.id "
            "JOIN books b ON c.book_id=b.id "
            "ORDER BY r.id DESC"
        )
        rows = cur.fetchall()
        conn.close()
        return rows
