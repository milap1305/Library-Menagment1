
from db import get_connection

class BookModel:
    def list_books(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM books ORDER BY id DESC")
        rows = cur.fetchall()
        conn.close()
        return rows

    def add_book(self, title, author, category, isbn):
        if not title:
            return False, "Title is required"
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO books (title, author, category, isbn) VALUES (?, ?, ?, ?)",
            (title, author, category, isbn),
        )
        conn.commit()
        conn.close()
        return True, "Book added"

    def delete_book(self, book_id):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM books WHERE id=?", (book_id,))
        conn.commit()
        conn.close()
        return True, "Deleted"
