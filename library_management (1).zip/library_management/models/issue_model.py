
from datetime import date
from db import get_connection

class IssueModel:
    def issue_book(self, copy_id, member_id, issue_date, due_date):
        if not copy_id or not member_id:
            return False, "Copy and member are required"
        conn = get_connection()
        cur = conn.cursor()

        # ensure copy is available (not issued/reserved)
        cur.execute("SELECT status FROM book_copies WHERE id=?", (copy_id,))
        row = cur.fetchone()
        if not row:
            conn.close()
            return False, "Copy not found"
        if row["status"] != "available":
            conn.close()
            return False, f"Copy is not available ({row['status']})"

        cur.execute(
            "INSERT INTO issues (copy_id, member_id, issue_date, due_date) VALUES (?, ?, ?, ?)",
            (copy_id, member_id, issue_date, due_date),
        )
        issue_id = cur.lastrowid

        # update copy status
        cur.execute("UPDATE book_copies SET status='issued' WHERE id=?", (copy_id,))

        conn.commit()
        conn.close()
        return True, issue_id

    def return_book(self, issue_id, return_date, penalty):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM issues WHERE id=?", (issue_id,))
        issue = cur.fetchone()
        if not issue:
            conn.close()
            return False, "Issue not found"
        if issue["return_date"]:
            conn.close()
            return False, "Already returned"

        cur.execute(
            "UPDATE issues SET return_date=?, penalty=? WHERE id=?",
            (return_date, penalty, issue_id),
        )

        # mark copy available again
        cur.execute("UPDATE book_copies SET status='available' WHERE id=?", (issue["copy_id"],))

        conn.commit()
        conn.close()
        return True, "Returned"

    def list_current_issues(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT i.id, m.name AS member_name, b.title AS book_title, "
            "c.serial_no, i.issue_date, i.due_date "
            "FROM issues i "
            "JOIN members m ON i.member_id=m.id "
            "JOIN book_copies c ON i.copy_id=c.id "
            "JOIN books b ON c.book_id=b.id "
            "WHERE i.return_date IS NULL "
            "ORDER BY i.id DESC"
        )
        rows = cur.fetchall()
        conn.close()
        return rows

    def list_returned(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT i.id, m.name AS member_name, b.title AS book_title, "
            "c.serial_no, i.issue_date, i.due_date, i.return_date, i.penalty "
            "FROM issues i "
            "JOIN members m ON i.member_id=m.id "
            "JOIN book_copies c ON i.copy_id=c.id "
            "JOIN books b ON c.book_id=b.id "
            "WHERE i.return_date IS NOT NULL "
            "ORDER BY i.id DESC"
        )
        rows = cur.fetchall()
        conn.close()
        return rows

    def get_issue_details(self, issue_id):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT i.id, m.name AS member_name, b.title AS book_title, "
            "c.serial_no, i.issue_date, i.due_date, i.return_date, i.penalty "
            "FROM issues i "
            "JOIN members m ON i.member_id=m.id "
            "JOIN book_copies c ON i.copy_id=c.id "
            "JOIN books b ON c.book_id=b.id "
            "WHERE i.id=?",
            (issue_id,),
        )
        row = cur.fetchone()
        conn.close()
        if not row:
            return False, "Issue not found"
        return True, row
