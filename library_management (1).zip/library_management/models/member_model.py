
from datetime import date
from db import get_connection

class MemberModel:
    def list_members(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM members ORDER BY id DESC")
        rows = cur.fetchall()
        conn.close()
        return rows

    def add_member(self, name, email, phone):
        if not name:
            return False, "Name is required"
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO members (name, email, phone, join_date) VALUES (?, ?, ?, ?)",
            (name, email, phone, date.today().isoformat()),
        )
        conn.commit()
        conn.close()
        return True, "Member added"
