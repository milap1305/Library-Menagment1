
from db import get_connection

class StockModel:
    def list_copies(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT c.id, c.serial_no, c.status, b.title AS book_title, b.id AS book_id "
            "FROM book_copies c JOIN books b ON c.book_id = b.id ORDER BY c.id DESC"
        )
        rows = cur.fetchall()
        conn.close()
        return rows

    def add_copy(self, book_id, serial_no):
        if not serial_no:
            return False, "Serial number is required"
        conn = get_connection()
        cur = conn.cursor()
        try:
            cur.execute(
                "INSERT INTO book_copies (book_id, serial_no, status) VALUES (?, ?, 'available')",
                (book_id, serial_no),
            )
            conn.commit()
        except Exception as e:
            conn.close()
            return False, str(e)
        conn.close()
        return True, "Copy added"

    def update_status(self, copy_id, status):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("UPDATE book_copies SET status=? WHERE id=?", (status, copy_id))
        conn.commit()
        conn.close()
        return True, "Status updated"

    def list_available_copies(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT c.id, c.serial_no, b.title AS book_title "
            "FROM book_copies c JOIN books b ON c.book_id=b.id "
            "WHERE c.status='available'"
        )
        rows = cur.fetchall()
        conn.close()
        return rows
