
import sqlite3
import os
from datetime import date

DB_NAME = os.path.join(os.path.dirname(__file__), "library.db")

def get_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    cur = conn.cursor()

    # Books master
    cur.execute("""
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            author TEXT,
            category TEXT,
            isbn TEXT
        )
    """)

    # Members master
    cur.execute("""
        CREATE TABLE IF NOT EXISTS members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            join_date TEXT
        )
    """)

    # Book copies (stock)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS book_copies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL,
            serial_no TEXT NOT NULL UNIQUE,
            status TEXT NOT NULL DEFAULT 'available',
            FOREIGN KEY(book_id) REFERENCES books(id)
        )
    """)

    # Issues
    cur.execute("""
        CREATE TABLE IF NOT EXISTS issues (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            copy_id INTEGER NOT NULL,
            member_id INTEGER NOT NULL,
            issue_date TEXT NOT NULL,
            due_date TEXT NOT NULL,
            return_date TEXT,
            penalty REAL DEFAULT 0,
            FOREIGN KEY(copy_id) REFERENCES book_copies(id),
            FOREIGN KEY(member_id) REFERENCES members(id)
        )
    """)

    # Reservations
    cur.execute("""
        CREATE TABLE IF NOT EXISTS reservations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            copy_id INTEGER NOT NULL,
            member_id INTEGER NOT NULL,
            reserve_date TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'reserved',
            FOREIGN KEY(copy_id) REFERENCES book_copies(id),
            FOREIGN KEY(member_id) REFERENCES members(id)
        )
    """)

    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
