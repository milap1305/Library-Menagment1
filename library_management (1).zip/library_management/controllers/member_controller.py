
class MemberController:
    def __init__(self, model):
        self.model = model

    def list_members(self):
        return self.model.list_members()

    def add_member(self, name, email, phone):
        return self.model.add_member(name, email, phone)
