
class BookController:
    def __init__(self, model):
        self.model = model

    def list_books(self):
        return self.model.list_books()

    def add_book(self, title, author, category, isbn):
        return self.model.add_book(title, author, category, isbn)

    def delete_book(self, book_id):
        return self.model.delete_book(book_id)
