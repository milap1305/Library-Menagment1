
class ReservationController:
    def __init__(self, model):
        self.model = model

    def reserve_copy(self, copy_id, member_id):
        return self.model.reserve_copy(copy_id, member_id)

    def cancel_reservation(self, res_id):
        return self.model.cancel_reservation(res_id)

    def list_reservations(self):
        return self.model.list_reservations()
