
class IssueController:
    def __init__(self, model):
        self.model = model

    def issue_book(self, copy_id, member_id, issue_date, due_date):
        return self.model.issue_book(copy_id, member_id, issue_date, due_date)

    def list_current_issues(self):
        return self.model.list_current_issues()

    def list_returned(self):
        return self.model.list_returned()

    def get_issue_details(self, issue_id):
        return self.model.get_issue_details(issue_id)

    def return_book(self, issue_id, return_date, penalty):
        return self.model.return_book(issue_id, return_date, penalty)
