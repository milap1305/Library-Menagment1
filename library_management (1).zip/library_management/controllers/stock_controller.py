
class StockController:
    def __init__(self, model):
        self.model = model

    def list_copies(self):
        return self.model.list_copies()

    def add_copy(self, book_id, serial_no):
        return self.model.add_copy(book_id, serial_no)

    def update_status(self, copy_id, status):
        return self.model.update_status(copy_id, status)

    def list_available_copies(self):
        return self.model.list_available_copies()
