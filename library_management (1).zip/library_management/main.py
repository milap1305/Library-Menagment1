
from tkinter import Tk
from tkinter import ttk

from db import init_db
from models.book_model import BookModel
from models.member_model import MemberModel
from models.stock_model import StockModel
from models.issue_model import IssueModel
from models.reservation_model import ReservationModel

from controllers.book_controller import BookController
from controllers.member_controller import MemberController
from controllers.stock_controller import StockController
from controllers.issue_controller import IssueController
from controllers.reservation_controller import ReservationController

from views.books_view import BooksView
from views.members_view import MembersView
from views.issue_view import IssueView
from views.return_view import ReturnView
from views.reservation_view import ReservationView

def main():
    init_db()

    root = Tk()
    root.title("Library Management System - Diploma Project")
    root.geometry("1100x650")

    nb = ttk.Notebook(root)
    nb.pack(fill="both", expand=True)

    # Models
    book_model = BookModel()
    member_model = MemberModel()
    stock_model = StockModel()
    issue_model = IssueModel()
    reservation_model = ReservationModel()

    # Controllers
    book_ctrl = BookController(book_model)
    member_ctrl = MemberController(member_model)
    stock_ctrl = StockController(stock_model)
    issue_ctrl = IssueController(issue_model)
    reservation_ctrl = ReservationController(reservation_model)

    # Views / Tabs
    books_tab = BooksView(nb, book_ctrl, stock_ctrl)
    members_tab = MembersView(nb, member_ctrl)
    issue_tab = IssueView(nb, issue_ctrl, stock_ctrl, member_ctrl)
    return_tab = ReturnView(nb, issue_ctrl)
    reservation_tab = ReservationView(nb, reservation_ctrl, stock_ctrl, member_ctrl)

    nb.add(books_tab, text="Books / Stock")
    nb.add(members_tab, text="Members")
    nb.add(issue_tab, text="Issue Books")
    nb.add(return_tab, text="Return Books")
    nb.add(reservation_tab, text="Reservations")

    root.mainloop()

if __name__ == "__main__":
    main()
